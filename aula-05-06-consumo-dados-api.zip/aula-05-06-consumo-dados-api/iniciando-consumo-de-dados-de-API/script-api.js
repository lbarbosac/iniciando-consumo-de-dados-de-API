
const URl = 'http://archive.opensearch.ceda.ac.uk/opensearch/description.xml';
console.log(URL);